#ifndef BOOKCLASS_H
#define BOOKCLASS_H
#include "Common.h"

class Book {
private:
  string ISBN13;
  string authors;
  string year;
  string title;
  string averageRating;
  string status;

public:
  // Constructors
  Book() {}
  ~Book() {}
  Book(string ISBN13, string authors, string year, string title,
       string averageRating, string status)
      : ISBN13(ISBN13), authors(authors), year(year), title(title),
        averageRating(averageRating), status(status) {}

  // Getters
  string getISBN13() const { return ISBN13; }
  string getAuthors() const { return authors; }
  string getYear() const { return year; }
  string getTitle() const { return title; }
  string getAverageRating() const { return averageRating; }
  string getStatus() const { return status; }

  // Setters
  void setISBN13(string i) { ISBN13 = i; }
  void setAuthors(string a) { authors = a; }
  void setYear(string y) { year = y; }
  void setTitle(string t) { title = t; }
  void setAverageRating(string rating) { averageRating = rating; }
  void setStatus(string s) { status = s; }

  // Display functions
  void displayDetails() {
    cout << "ISBN: " << ISBN13 << endl;
    cout << "Author(s): " << authors << endl;
    cout << "Year: " << year << endl;
    cout << "Title: " << title << endl;
    cout << "Average Rating: " << averageRating << endl;
    cout << "Status: " << displayStatus() << endl;
  }

  string displayStatus() const {
    if (status.find("Available") != string::npos) {
      return "Available";
    }
    if (status.find("On Hold:") != string::npos) {
      return "On Hold by ";
    }
    if (status.find("Checked Out:") != string::npos) {
      return "Checked Out";
    }
    return status;
  }

  // Valid details function
  bool validDetails(string i, string a, string y, string t, string rating,
                    string s) {
    return (!i.empty() && !a.empty() && !y.empty() && !t.empty() &&
            !rating.empty() &&
            (s == "holding" || s == "available" || s == "checked out"));
  }
};
#endif // BOOKCLASS_H
