#include <iostream>
#include <vector>
#include <array>
#include <iostream>
#include <iomanip>
#include "BookClass.cpp"
using namespace std;

class User{
public:
    string memberId, fName,lName,email,address;
    int phoneNum;
    vector <Book> userBooks;

    //various contructors for creating new users
    User(){}
    User(string memberId, string fName, string lName, string email): memberId(memberId), fName(fName), lName(lName), email(email){}
    User(string memberId, string fName, string lName): memberId(memberId), fName(fName), lName(lName){}
    User(string memberId, string fName, string lName, string email, string address, int phoneNum):  memberId(memberId), fName(fName), lName(lName), email(email), address(address), phoneNum(phoneNum){}

    //getters
    string getMemberId(){
        return memberId;
    }
    string getFirstName(){
        return fName;
    }
    string getLastName(){
        return lName;
    }
    string getEmail(){
        return email;
    }
    string getAddress(){
        return address;
    }
    int getPhoneNum(){
        return phoneNum;
    }

    //setters
    void setMemberId(string newMemId){
        memberId = newMemId;
    }
    void setFirstName(string newFName){
        fName = newFName;
    }
    void setLastName(string newLName){
        lName = newLName;
    }
    void setEmail(string newEmail){
        email = newEmail;
    }
    void setAddress(string newAddress){
        address = newAddress;
    }
    void setPhoneNum(int newPhoneNum){
        phoneNum = newPhoneNum;
    }
    //shorthand display of user's main account details
    void displayAccount(User newUser){
        cout<<"First Name: "<< newUser.fName<<endl;
        cout<<"Last Name: "<< newUser.lName<<endl;
        cout<<"Membership ID: "<< newUser.memberId<<endl;

    }
    //extended display of user's account details, including current books checked out
    void displayAccountExtended(User newUser){
        cout<<"First Name: "<< newUser.fName<<endl;
        cout<<"Last Name: "<< newUser.lName<<endl;
        cout<<"Membership ID: "<< newUser.memberId<<endl;
        cout<<"Email: "<< newUser.email<<endl;
        cout<<"Address: "<< newUser.address<<endl;
        cout<<"Phone Number: "<< newUser.phoneNum<<endl;
        cout<<"Books checked out: "<<endl;
        for(int i=0;i<userBooks.size();i++){
            cout<<userBooks[i].getTitle()<<endl;
          }

    }
        //function to check out a book. changes book's status to checked out, and enters it into the user's collection
    void checkOut(Book book){
        /*book.checkOutDate = now
         * book.status = "checked out" or true?
         * book.owner = user.fName, user.lName, user.memId?
         * */
        book.setStatus("checked out");
          userBooks.push_back(book);
    }
        //function that only places a book on hold
    void placeHold(Book book){
        /*if (book.status == "checkout" / true){
         *book.status = "holding/on wait"
         *or
         *book.holdStatus = "holding/on wait"
         * */
        book.setStatus("holding");
    }
        //function to return a book. changes its status to available, and removes it from the user's collection
    void returnBook(Book book){
        /*if(book.daysCheckedOut > book.daysAllowed){
         * fee calculations
         * }
         *
         * book.status = "available" or false?
         * book.checkOutDate = 0
         * book.owner = ""
         *
         * */
        book.setStatus("available");
        for (int i=0; i<userBooks.size(); i++){     //vectors are weird and don't let you delete a specific index,                                         so you gotta start from index 0 and add whatever index you are trying to reach
            if(userBooks[i].getTitle() == book.getTitle()){
                userBooks.erase(userBooks.begin() + (i-1));
            }
        }

    }
};


