#ifndef Classes
#define Classes
#include "Common.h"

/* Book Class Move to an H file to fix complications with compiling */
class Book {
private:
    string ISBN13;
    string authors;
    string year;
    string title;
    string averageRating;
    string status;

public:
    // Constructors
    Book() {}
    ~Book() {}
    Book(string ISBN13, string authors, string year, string title, string averageRating, string status)
        : ISBN13(ISBN13), authors(authors), year(year), title(title), averageRating(averageRating), status(status) {}

    // Getters
    string getISBN13() const {
        return ISBN13;
    }
    string getAuthors() const {
        return authors;
    }
    string getYear() const {
        return year;
    }
    string getTitle() const {
        return title;
    }
    string getAverageRating() const {
        return averageRating;
    }
    string getStatus() const {
        return status;
    }

    // Setters
    void setISBN13(string i) {
        ISBN13 = i;
    }
    void setAuthors(string a) {
        authors = a;
    }
    void setYear(string y) {
        year = y;
    }
    void setTitle(string t) {
        title = t;
    }
    void setAverageRating(string rating) {
        averageRating = rating;
    }
    void setStatus(string s) {
        status = s;
    }

    // Display functions
    void displayDetails() {
        cout << "ISBN: " << ISBN13 << endl;
        cout << "Author(s): " << authors << endl;
        cout << "Year: " << year << endl;
        cout << "Title: " << title << endl;
        cout << "Average Rating: " << averageRating << endl;
        cout << "Status: " << displayStatus() << endl;
    }

    string displayStatus() const {
        if (status.find("Available") != string::npos) { return "Available"; }
        if (status.find("On Hold:") != string::npos) { return "On Hold by "; }
        if (status.find("Checked Out:") != string::npos) { return "Checked Out"; }
        return status;
    }

    // Valid details function
    bool validDetails(string i, string a, string y, string t, string rating, string s) {
        return (!i.empty() && !a.empty() && !y.empty() && !t.empty() && !rating.empty() && (s == "holding" || s == "available" || s == "checked out"));
    }

};

/* User Class Moved to an H file to fix complications with compiling */

class User {
public:
    string memberID, fName, lName, email, address, phoneNum;
    map<string, Book> userBooks;


    // Constructors
    User() {}
    User(string memberID, string fName, string lName, string email, string phoneNum) : memberID(memberID), fName(fName), lName(lName), email(email), phoneNum(phoneNum) {}
    User(string memberID, string fName, string lName, string phoneNum) : memberID(memberID), fName(fName), lName(lName), phoneNum(phoneNum) {}
    User(string memberID, string fName, string lName, string email, string address, string phoneNum) : memberID(memberID), fName(fName), lName(lName), email(email), address(address), phoneNum(phoneNum) {}

    // Getters
    string getMemberID() const {
        return memberID;
    }
    string getFirstName() const {
        return fName;
    }
    string getLastName() const {
        return lName;
    }
    string getName() const {
        return fName + " " + lName;
    }
    string getEmail() const {
        return email;
    }
    string getAddress() const {
        return address;
    }
    string getPhoneNum() const {
        return phoneNum;
    }

    // Setters
    void setMemberID(string newMemID) {
        memberID = newMemID;
    }
    void setFirstName(string newFName) {
        fName = newFName;
    }
    void setLastName(string newLName) {
        lName = newLName;
    }
    void setEmail(string newEmail) {
        email = newEmail;
    }
    void setAddress(string newAddress) {
        address = newAddress;
    }
    void setPhoneNum(string newPhoneNum) {
        phoneNum = newPhoneNum;
    }

    // Display functions
    void displayAccount() const {
        cout << "First Name: " << fName << endl;
        cout << "Last Name: " << lName << endl;
        cout << "Membership ID: " << memberID << endl;
        cout << endl;
    }

    void displayAccountExtended() const {
        cout << "First Name: " << fName << endl;
        cout << "Last Name: " << lName << endl;
        cout << "Membership ID: " << memberID << endl;
        cout << "Email: " << email << endl;
        cout << "Address: " << address << endl;
        cout << "Phone Number: " << phoneNum << endl;
        cout << "Books checked out: " << endl;
        for (auto it = userBooks.begin(); it != userBooks.end(); it++) {
            cout << it->second.getTitle() << endl;
        }
        cout << endl;
    }
    /*
        // Check-out, Place-hold, Return functions
        void checkOut(Book& book) {
            book.setStatus("checked out");
            userBooks.push_back(book);
        }

        void placeHold(Book& book) {
            book.setStatus("holding");
        }

        void returnBook(Book& book) {
            book.setStatus("available");
            for (auto it = userBooks.begin(); it != userBooks.end(); ++it) {
                if (it->getTitle() == book.getTitle()) {
                    userBooks.erase(it);
                    break;
                }
            }
        }
    */
    bool isEmailUnique(const string& email, map<string, User> patrons);
};

class LibrarySystem {
private:
    //All books in the library, searchable by ISBN
    map<string, Book> bookCollection;
    //All patrons of the library, searchable by MemberID
    map<string, User> patrons;

    //Functions
    void populateBookCollection();
    void populatePatronListFromFile();

public:
    //Constructors
    LibrarySystem();
    ~LibrarySystem() {}

    //Print
    void PrintAllBooks();
    void PrintAllUsers();

    //Accessors
    map<string, Book> getBookCollection();
    map<string, User> getPatronList();

    //Mutators
    void AddBookToList(Book newBook);
    void RemoveBookFromList(string ISBN);
    void RemoveBookFromList(Book oldBook);

    void addUser(User newUser);
    // Fixed Removed User Function errors and fixed the duplicate definition
    void removeUser(const User& oldUser);
    void removeUser(string memberID);

    void checkOutBook(string ISBN, User& user);
    void returnBook(string ISBN, User& user);
    void placeHoldBook(string ISBN, User& user);
    void removeHoldBook(string ISBN, User& user);

    //Andrew
    void addUserCSV(const User& newUser);
    void deleteUserCSV(const User& newUser);
};

LibrarySystem::LibrarySystem() {
    populateBookCollection();
    populatePatronListFromFile();
}

void LibrarySystem::populateBookCollection() {
    // Correct error handing, instead of exiting the program it will throw an exception
    ifstream bookList("books.csv");
    if (!bookList.is_open()) {
        throw runtime_error("Could not open file.");
    }
    string line;
    string data;
    Book book;
    while (getline(bookList, line)) {
        istringstream lineParser(line);
        getline(lineParser, data, ',');	//ISBN
        book.setISBN13(data);
        getline(lineParser, data, ',');	//Authors  //Check Case: Multiple Authors?
        book.setAuthors(data);
        getline(lineParser, data, ',');	//Year
        book.setYear(data);
        getline(lineParser, data, ',');	//Title
        book.setTitle(data);
        getline(lineParser, data);	//Rating
        book.setAverageRating(data);
        book.setStatus("Available");
        //Finished line
        bookCollection[book.getISBN13()] = book;
    }
    bookList.close();
}

void LibrarySystem::populatePatronListFromFile() {
    ifstream patronList;
    patronList.open("users.csv");
    if (!patronList.is_open()) { cout << "Could not open file." << endl; exit(1); }

    string fName, lName, email, address, phoneNum;
    string line;
    int memberID = 0; // Initialize memberID outside the loop

    while (getline(patronList, line)) {
        istringstream lineParser(line);
        getline(lineParser, fName, ',');
        getline(lineParser, lName, ',');
        getline(lineParser, email, ',');
        getline(lineParser, address, ',');
        getline(lineParser, phoneNum);

        // Increment memberID before assigning it to the user
        memberID++;

        // Create a new user and add it to the patrons map
        patrons[to_string(memberID)] = User(to_string(memberID), fName, lName, email, address, phoneNum);
    }
    patronList.close();
}


void LibrarySystem::PrintAllBooks() {
    //Iterate over book map
    for (auto iterator = bookCollection.begin(); iterator != bookCollection.end(); ++iterator) {
        iterator->second.displayDetails();
    }
}

void LibrarySystem::PrintAllUsers() {
    //Iterate over User Map
    // Fixed error too many arguments, removed iteraotor->second since its not required
    for (auto iterator = patrons.begin(); iterator != patrons.end(); iterator++) {
        iterator->second.displayAccountExtended();
    }
}

map<string, Book> LibrarySystem::getBookCollection() {
    return bookCollection;
}

map<string, User> LibrarySystem::getPatronList() {
    return patrons;
}

void LibrarySystem::AddBookToList(Book newBook) {
    //TODO: Check for existing book
    bookCollection[newBook.getISBN13()] = newBook;
}


void LibrarySystem::RemoveBookFromList(Book oldBook) {
    bookCollection.erase(oldBook.getISBN13());
}

void LibrarySystem::RemoveBookFromList(string ISBN) {
    bookCollection.erase(ISBN);
}

void LibrarySystem::addUser(User newUser) {
    patrons[newUser.getMemberID()] = newUser;
}

void LibrarySystem::removeUser(const User& oldUser) {
    patrons.erase(oldUser.getMemberID());
}

void LibrarySystem::removeUser(string memberID) {
    patrons.erase(memberID);
}

void LibrarySystem::checkOutBook(string ISBN, User& user) {
    if (bookCollection.find(ISBN) != bookCollection.end()) {
        if (bookCollection[ISBN].getStatus().find("Available") != string::npos) {
            placeHoldBook(ISBN, user);
        }

        if (bookCollection[ISBN].getStatus().find("On Hold:") != string::npos) {
            if (bookCollection[ISBN].getStatus().find(user.getMemberID()) != string::npos) {
                bookCollection[ISBN].setStatus("Checked Out:" + user.getMemberID());
                user.userBooks[ISBN] = bookCollection[ISBN];
                cout << bookCollection[ISBN].getTitle() << " checked out for user: " << user.getName() << endl;
            }
            else {
                cout << user.getName() << " has not placed a hold on this book." << endl;
            }
        }
        else {
            cout << "This book is not available." << endl;
        }
    }
    else {
        cout << "Book not found." << endl;
    }
}

void LibrarySystem::returnBook(string ISBN, User& user) {
    if (bookCollection.find(ISBN) != bookCollection.end()) {
        if (bookCollection[ISBN].getStatus().find("Checked Out:") != string::npos) {
            if (bookCollection[ISBN].getStatus().find(user.getMemberID()) != string::npos) {
                bookCollection[ISBN].setStatus("Available");
                user.userBooks.erase(ISBN);
                cout << bookCollection[ISBN].getTitle() << " has been returned." << endl;
            }
            else {
                cout << user.getName() << " has not checked out this book." << endl;
            }
        }
        else {
            cout << "This book is not checked out." << endl;
        }
    }
    else {
        cout << "Book not found." << endl;
    }
}

void LibrarySystem::placeHoldBook(string ISBN, User& user) {
    if (bookCollection.find(ISBN) != bookCollection.end()) {
        if (bookCollection[ISBN].getStatus() == "Available") {
            bookCollection[ISBN].setStatus("On Hold:" + user.getMemberID());
            cout << bookCollection[ISBN].getTitle() << " on hold for user: " << user.getName() << endl;
        }
        else {
            cout << "This book is not available." << endl;
        }
    }
    else {
        cout << "Book not found." << endl;
    }
}

void LibrarySystem::removeHoldBook(string ISBN, User& user) {
    if (bookCollection.find(ISBN) != bookCollection.end()) {
        if (bookCollection[ISBN].getStatus().find("On Hold:") != string::npos) {
            if (bookCollection[ISBN].getStatus().find(user.getMemberID()) != string::npos) {
                bookCollection[ISBN].setStatus("Available");
                cout << bookCollection[ISBN].getTitle() << " is now available." << endl;
            }
            else {
                cout << user.getName() << " has not placed a hold on this book." << endl;
            }
        }
        else {
            cout << "This book is not on hold." << endl;
        }
    }
    else {
        cout << "Book not found." << endl;
    }
}
void LibrarySystem::addUserCSV(const User& newUser) {
    ofstream file("users.csv", ios::app);
    if (!file.is_open()) {
        throw runtime_error("Could not open file.");
    }
    file << newUser.getFirstName() << "," << newUser.getLastName() << ","
        << newUser.getEmail() << "," << newUser.getAddress() << ","
        << newUser.getPhoneNum() << endl;

    file.close();
}

/*
void LibrarySystem::deleteUserCSV(const User& newUser){

}

bool User::isEmailUnique(const string& email, map<string, User> patronsList){
 //f
  return true;
}


bool User::isEmailUnique(const string& email, map<string, User> patronList){
  for (const auto &patron: patronList){
    if(patron.second.getEmail() == email){
      return false;
    }
    return true;
  }
  */


#endif