#ifndef LIBRARYSYSTEMCLASS
#define LIBRARYSYSTEMCLASS
#include "BookClass.cpp"
#include "Common.h"
#include "UserClass.cpp"

class LibrarySystem {
private:
  // All books in the library, searchable by ISBN
  map<string, Book> bookCollection;
  // All patrons of the library, searchable by MemberID
  map<string, User> patrons;

  // Functions
  void populateBookCollection();
  void populatePatronListFromFile();

public:
  // Constructors
  LibrarySystem();
  ~LibrarySystem() {}

  // Print
  void PrintAllBooks();
  void PrintAllUsers();

  // Mutators
  void AddBookToList(Book newBook);
  void RemoveBookFromList(string ISBN);
  void RemoveBookFromList(Book oldBook);

  void addUser(User newUser);
  // Fixed Removed User Function errors and fixed the duplicate definition
  void removeUser(const User &oldUser);
  void removeUser(string memberID);
};

LibrarySystem::LibrarySystem() {
  populateBookCollection();
  populatePatronListFromFile();
}

void LibrarySystem::populateBookCollection() {
  // Correct error handing, instead of exiting the program it will throw an
  // exception
  ifstream bookList("books.csv");
  if (!bookList.is_open()) {
    throw runtime_error("Could not open file.");
  }
  string line;
  string data;
  Book book;
  while (getline(bookList, line)) {
    istringstream lineParser(line);
    getline(lineParser, data, ','); // ISBN
    book.setISBN13(data);
    getline(lineParser, data, ','); // Authors  //Check Case: Multiple Authors?
    book.setAuthors(data);
    getline(lineParser, data, ','); // Year, not used
    getline(lineParser, data, ','); // Title
    book.setTitle(data);
    getline(lineParser, data); // Rating, not used
    // Finished line
    bookCollection[book.getISBN13()] = book;
  }
  bookList.close();
}

void LibrarySystem::populatePatronListFromFile() {
  ifstream patronList;
  patronList.open("users.csv");
  if (!patronList.is_open()) {
    cout << "Could not open file." << endl;
    exit(1);
  }

  string fName, lName, email, address, phoneNum;
  string line;
  int memberID = 0; // Initialize memberID outside the loop

  while (getline(patronList, line)) {
    istringstream lineParser(line);
    getline(lineParser, fName, ',');
    getline(lineParser, lName, ',');
    getline(lineParser, email, ',');
    getline(lineParser, address, ',');
    getline(lineParser, phoneNum);

    // Increment memberID before assigning it to the user
    memberID++;

    // Create a new user and add it to the patrons map
    patrons[to_string(memberID)] =
        User(to_string(memberID), fName, lName, email, address, stoi(phoneNum));
  }
  patronList.close();
}

void LibrarySystem::PrintAllBooks() {
  // Iterate over book map
  for (auto iterator = bookCollection.begin(); iterator != bookCollection.end();
       iterator++) {
    iterator->second.displayDetails();
  }
}

void LibrarySystem::PrintAllUsers() {
  // Iterate over User Map
  //  Fixed error too many arguments, removed iteraotor->second since its not
  //  required
  for (auto iterator = patrons.begin(); iterator != patrons.end(); iterator++) {
    iterator->second.displayAccountExtended();
  }
}

void LibrarySystem::AddBookToList(Book newBook) {
  // TODO: Check for existing book
  bookCollection[newBook.getISBN13()] = newBook;
}

void LibrarySystem::RemoveBookFromList(Book oldBook) {
  bookCollection.erase(oldBook.getISBN13());
}

void LibrarySystem::RemoveBookFromList(string ISBN) {
  bookCollection.erase(ISBN);
}

void LibrarySystem::addUser(User newUser) {
  patrons[newUser.getMemberID()] = newUser;
}

void LibrarySystem::removeUser(const User &oldUser) {
  patrons.erase(oldUser.getMemberID());
}

void LibrarySystem::removeUser(string memberID) { patrons.erase(memberID); }

#endif // LIBRARYSYSTEMCLASS
