// Margarita Guzman, Chance Benna, Quinn Nagel, Yousef Al-Bakri, Andrew Avis
// Team Alpha project Library System

#include "BookClass.h"
#include "Common.h"
#include "LibrarySystemClass.h"
#include "UserClass.h"

void clearConsole();

int main() {
  // Switch Case Choice Value 1-8
  int choice;
  // Deeper Layer of UI Engagement 1-2 for both
  int nestedChoice;
  // User class specific variables
  string userISBN;
  string userID;
  LibrarySystem library;

  // Loop For Main UI
  while (true) {
    clearConsole();
    cout << "Welcome to the Library System!" << endl;
    cout << "------------------------------" << endl;
    cout << "Please select an option (1-8): " << endl;
    cout << "1. Return a Book" << endl;
    cout << "2. Check out a Book" << endl;
    cout << "3. Place a Book on Hold" << endl;
    cout << "4. Display Book Details" << endl;
    cout << "5. Add / Remove a Book" << endl;
    cout << "6. Display Account Details" << endl;
    cout << "7. Add / Remove an Account" << endl;
    cout << "8. Exit Program" << endl;
    choice = getInt(1, 8, "Select an option: ");

    // Main UI Switch Case
    switch (choice) {
      // Yousef Al-Bakri
    case 1: {
      // Output Case Info:
      clearConsole();
      cout << "Returning a Book!" << endl;
      cout << "------------------------" << endl;

      // Input and Validation:
      userID = to_string(getInt(1, library.getPatronList().size(),
                                "Please enter your User ID Number: "));
      cout << "Please enter the ISBN of the book you would like to return: ";
      cin >> userISBN;
      while (library.getBookCollection().find(userISBN) ==
             library.getBookCollection().end()) {
        cout << "Book not found.  Enter an ISBN: ";
        cin >> userISBN;
      }

      // Case 1 Main:
      library.returnBook(userISBN, library.getPatronList()[userID]);
      break;
    }

      // Yousef Al-Bakri
    case 2: {
      // Output Case Info:
      clearConsole();
      cout << "Checking out a Book!" << endl;
      cout << "------------------------" << endl;

      // Input and Validation:
      userID = to_string(getInt(1, library.getPatronList().size(),
                                "Please enter your User ID Number: "));
      cout << "Please enter the ISBN of the book you would like to check out: ";
      cin >> userISBN;
      while (library.getBookCollection().find(userISBN) ==
             library.getBookCollection().end()) {
        cout << "Book not found.  Enter an ISBN: ";
        cin >> userISBN;
      }

      // Case 2 Main:
      library.checkOutBook(userISBN, library.getPatronList()[userID]);
      break;
    }

      // Margarita Guzman
    case 3: {
      // Output Case Info:
      clearConsole();
      cout << "Placing a book on hold!" << endl;
      cout << "------------------------" << endl;

      // Input and Validation:
      userID = to_string(getInt(1, library.getPatronList().size(),
                                "Please enter your User ID Number: "));
      cout << "Please enter the ISBN of the book you would like to place on "
              "hold: ";
      cin >> userISBN;
      while (library.getBookCollection().find(userISBN) ==
             library.getBookCollection().end()) {
        cout << "Book not found.  Enter an ISBN: ";
        cin >> userISBN;
      }

      // Case 3 Main:
      library.placeHoldBook(userISBN, library.getPatronList()[userID]);
      break;
    }

      // Quinn Nagel
    case 4: {
      // Output Case Info:
      clearConsole();
      cout << "Finding a Book!" << endl;
      cout << "------------------------" << endl;

      // Input and Validation:
      cout << "Please enter the ISBN of the book you would like to display: ";
      cin >> userISBN;
      while (library.getBookCollection().find(userISBN) ==
             library.getBookCollection().end()) {
        cout << "Book not found. Enter an ISBN: ";
        cin >> userISBN;
      }

      // Check if book exists before displaying details:
      auto bookCollection = library.getBookCollection();
      auto it = bookCollection.find(userISBN);
      if (it != bookCollection.end()) {
        it->second.displayDetails();
      } else {
        cout << "Book not found." << endl;
      }
      break;
    }
      // Quinn Nagel
    case 5: {
      // Output Case Info:
      clearConsole();
      cout << "Adding or Removing Books" << endl;
      cout << "------------------------" << endl;
      cout << "Select 1 to Add a Book to the Library" << endl;
      cout << "Select 2 to Remove a Book from the Library" << endl;
      nestedChoice = getInt(1, 2, "Select an option: ");

      // Case 5 Main:
      switch (nestedChoice) {
      case 1: {
        clearConsole();
        cout << "Adding a Book" << endl;
        cout << "------------------------" << endl;

        // Input and Validation
        cin.ignore();
        string ISBN, authors, year, title, averageRating, status = "Available";
        cout << "Enter the ISBN of the book: ";
        getline(cin, ISBN);
        cout << "Enter the Authors of the book: ";
        getline(cin, authors);
        cout << "Enter the Year of the book: ";
        getline(cin, year);
        cout << "Enter the Title of the book: ";
        getline(cin, title);
        cout << "Enter the Average Rating of the book: ";
        getline(cin, averageRating);
        // Changed back to getline for year and average rating. MG
        // year = getInt(-7000, CURRENT_YEAR, "Enter the Year of Publication of
        // the Book: "); averageRating = getDouble(0, 5, "Enter the Average
        // Rating of the book: ");
        //  Create a new Book object
        Book newBook =
            *(new Book(ISBN, authors, year, title, averageRating, status));

        // Case 5-1 Main:
        //  Add the new Book to the collection
        library.AddBookToList(newBook);
        cout << "Book added successfully." << endl;
        break;
      }

      case 2: {
        clearConsole();
        cout << "Removing a Book" << endl;
        cout << "------------------------" << endl;

        // Input and Validation
        cout << "Please enter the ISBN of the book you would like to remove: ";
        cin >> userISBN;
        while (library.getBookCollection().find(userISBN) ==
               library.getBookCollection().end()) {
          cout << "Book not found.  Enter an ISBN: ";
          cin >> userISBN;
        }

        // Case 5-2 Main:
        library.RemoveBookFromList(userISBN);
        cout << "Book removed successfully!" << endl;
        break;
      }

      default: {
        cout << "Error! Enter either 1 or 2!" << endl;
        break;
      }
      }
      break;
    }

      // Chance Benna
      //  Quinn - Added a protection if the account doesn't exist - 3/4/24
    case 6: {
      clearConsole();
      cout << "Display Account Details!" << endl;
      cout << "------------------------" << endl;
      cout << "Please enter the membership ID of said account: " << endl;
      cin >> userID;
      cout << "Select 1 for Basic Details, 2 for Extended Details" << endl;
      nestedChoice = getInt(1, 2, "Select an option: ");

      if (library.getPatronList().find(userID) !=
          library.getPatronList().end()) {
        if (nestedChoice == 1) {
          library.getPatronList()[userID].displayAccount();
        } else if (nestedChoice == 2) {
          library.getPatronList()[userID].displayAccountExtended();
        }
      } else {
        cout << "Account with ID " << userID << " does not exist." << endl;
      }

      cout << "Displayed Account Details" << endl;
      break;
    }

    case 7: { // Andrew Avis
      clearConsole();
      cout << "Adding or Removing an Account!" << endl;
      cout << "------------------------" << endl;
      cout << "Add / Remove an Account ( 1 or 2 )" << endl;
      cout << "You may need to restart to populate the new account."<< endl; // added for clarification. MG
      cin >> nestedChoice;

      if (nestedChoice == 1) {
        User newUser;
        cout << "Enter email: " << endl;
        cin >> newUser.email;
        cout << "Enter first name: " << endl;
        cin >> newUser.fName;
        cout << "Enter last name: " << endl;
        cin >> newUser.lName;
        cout << "Enter address: " << endl;
        cin >> newUser.address;
        cout << "Enter phone number: " << endl;
        cin >> newUser.phoneNum;
        
        library.addUser(newUser); // Add the new user to the library. MG

        library.addUserCSV(newUser); // add the new user to the csv file. AA

        cout << "Added an Account" << endl;
        newUser.displayAccount();

      }

      else if (nestedChoice == 2) {
        string idToRemove;
        cout << "Enter the member id of the account you would like to remove: "
             << endl;
        cin >> idToRemove;

        library.deleteUserCSV(idToRemove);

        library.removeUser(idToRemove);
        cout << "Removed an Account" << endl;

      } else {
        cout << "Invalid Choice" << endl;
      }
      break;

    }

    case 8: {
      clearConsole();
      cout << "Exiting Program" << endl;
      cout << "How did you get here? 0_0" << endl;
    }

    default: {
      clearConsole();
      cout << "Invalid choice. Please try again." << endl;
      cout << endl;
      break;
    }
    }

    string tempString;
    cout << "Input anything to continue: ";
    cin >> tempString;
    cin.ignore();
  }

  return 0;
}

void clearConsole() { cout << "\x1B[2J\x1B[H"; }
