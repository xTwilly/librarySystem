#ifndef BookClass
#define BookClass
#include "Common.h"

class Book {
private:
  // Variables added based on Andrews's CSV file. MG
  string ISBN13;
  string authors;
  int year;
  string title;
  double averageRating;
  string status;

public:
  // Constructor, MG
  Book() {}
  ~Book() {}
  Book(string ISBN13, string authors, int year, string title,
       double averageRating, string status)
      : ISBN13(ISBN13), authors(authors), year(year), title(title),
        averageRating(averageRating), status(status) {}

  // Getters - Modified to have const
  string getISBN13() const { return ISBN13; }
  string getAuthors() const { return authors; }
  int getYear() const { return year; }
  string getTitle() const { return title; }
  double getAverageRating() const { return averageRating; }
  string getStatus() const { return status; }

  // Setters. MG
  void setISBN13(string i) { ISBN13 = i; }
  void setAuthors(string a) { authors = a; }
  void setYear(int y) { year = y; }
  void setTitle(string t) { title = t; }
  void setAverageRating(double rating) { averageRating = rating; }
  void setStatus(string s) { status = s; }

  // Display function. MG
  void displayDetails() {
    cout << "ISBN: " << ISBN13 << endl;
    cout << "Author(s): " << authors << endl;
    cout << "Year: " << year << endl;
    cout << "Title: " << title << endl;
    cout << "Average Rating: " << averageRating << endl;
    cout << "Status: " << endl;
  }

  // Valid details function. MG
  bool validDetails(string i, string a, int y, string t, double rating,
                    string s) {
    return (!i.empty() && !a.empty() && y > 0 && !t.empty() && rating >= 0 &&
            (s == "holding" || s == "available" || s == "checked out"));
  }

  // Update details function. MG
  void updateDetails() {
    string newISBN13, newAuthors, newTitle, newStatus;
    int newYear;
    double newRating;

    cout << "Enter the new ISBN: ";
    cin >> newISBN13;

    cout << "Enter the new author(s): ";
    cin.ignore();
    getline(cin, newAuthors);

    cout << "Enter the new year: ";
    cin >> newYear;

    cout << "Enter the new title: ";
    cin.ignore();
    getline(cin, newTitle);

    cout << "Enter the new average rating: ";
    cin >> newRating;

    cout << "Enter the new status: ";
    cin >> newStatus;

    if (validDetails(newISBN13, newAuthors, newYear, newTitle, newRating,
                     newStatus)) {
      setISBN13(newISBN13);
      setAuthors(newAuthors);
      setYear(newYear);
      setTitle(newTitle);
      setAverageRating(newRating);
      setStatus(newStatus);

      cout << "Details updated successfully" << endl;
    } else {
      cout << "Invalid details entered" << endl;
    }
  }

  // Set imported details. MG
  void setImportedDetails(string importedISBN13, string importedAuthors,
                          int importedYear, string importedTitle,
                          double importedRating, string importedStatus) {
    if (validDetails(importedISBN13, importedAuthors, importedYear,
                     importedTitle, importedRating, importedStatus)) {
      ISBN13 = importedISBN13;
      authors = importedAuthors;
      year = importedYear;
      title = importedTitle;
      averageRating = importedRating;
      status = importedStatus;
    } else {
      cout << "Invalid data imported for book." << endl;
    }
  }
};

#endif
