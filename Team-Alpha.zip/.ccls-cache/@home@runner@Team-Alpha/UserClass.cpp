#ifndef UserClass
#define UserClass
#include "BookClass.cpp"
#include "Common.h"

class User {
public:
  string memberID, fName, lName, email, address;
  vector<Book> userBooks;
  int phoneNum;

  // various contructors for creating new users
  User() {}
  User(string memberID, string fName, string lName, string email, int phoneNum)
      : memberID(memberID), fName(fName), lName(lName), email(email),
        phoneNum(phoneNum) {}
  User(string memberID, string fName, string lName, int phoneNum)
      : memberID(memberID), fName(fName), lName(lName), phoneNum(phoneNum) {}
  User(string memberID, string fName, string lName, string email,
       string address, int phoneNum)
      : memberID(memberID), fName(fName), lName(lName), email(email),
        address(address), phoneNum(phoneNum) {}

  // getters
  //  Added Const since it will not modify the variable state
  string getMemberID() const { return memberID; }

  string getFirstName() const { return fName; }
  string getLastName() const { return lName; }
  string getEmail() const { return email; }
  string getAddress() const { return address; }
  int getPhoneNum() const { return phoneNum; }

  // setters
  void setMemberID(string newMemID) { memberID = newMemID; }
  void setFirstName(string newFName) { fName = newFName; }
  void setLastName(string newLName) { lName = newLName; }
  void setEmail(string newEmail) { email = newEmail; }
  void setAddress(string newAddress) { address = newAddress; }
  void setPhoneNum(int newPhoneNum) { phoneNum = newPhoneNum; }

  // Display functions modified - no need to pass the arguments since they are a
  // part of the same class
  void displayAccount() const {
    cout << "First Name: " << fName << endl;
    cout << "Last Name: " << lName << endl;
    cout << "Membership ID: " << memberID << endl;
  }

  void displayAccountExtended() const {
    cout << "First Name: " << fName << endl;
    cout << "Last Name: " << lName << endl;
    cout << "Membership ID: " << memberID << endl;
    cout << "Email: " << email << endl;
    cout << "Address: " << address << endl;
    cout << "Phone Number: " << phoneNum << endl;
    cout << "Books checked out: " << endl;
    for (const Book &book : userBooks) {
      cout << book.getTitle() << endl;
    }
  }

  // Check-out, Place-hold, Return functions - modified to pass book by
  // reference
  void checkOut(Book &book) {
    book.setStatus("checked out");
    userBooks.push_back(book);
  }

  void placeHold(Book &book) { book.setStatus("holding"); }

  // Return Book - modified to erase better
  void returnBook(Book &book) {
    book.setStatus("available");
    for (auto it = userBooks.begin(); it != userBooks.end(); ++it) {
      if (it->getTitle() == book.getTitle()) {
        userBooks.erase(it);
        break; // No need to continue searching
      }
    }
  }
};

#endif
