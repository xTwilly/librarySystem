#ifndef USERCLASS_H
#define USERCLASS_H
#include "BookClass.h"
#include "Common.h"

class User {
public:
  string memberID, fName, lName, email, address, phoneNum;
  map<string, Book> userBooks;

  // Constructors
  User() {}
  User(string memberID, string fName, string lName, string email,
       string phoneNum)
      : memberID(memberID), fName(fName), lName(lName), email(email),
        phoneNum(phoneNum) {}
  User(string memberID, string fName, string lName, string phoneNum)
      : memberID(memberID), fName(fName), lName(lName), phoneNum(phoneNum) {}
  User(string memberID, string fName, string lName, string email,
       string address, string phoneNum)
      : memberID(memberID), fName(fName), lName(lName), email(email),
        address(address), phoneNum(phoneNum) {}

  // Getters
  string getMemberID() const { return memberID; }
  string getFirstName() const { return fName; }
  string getLastName() const { return lName; }
  string getName() const { return fName + " " + lName; }
  string getEmail() const { return email; }
  string getAddress() const { return address; }
  string getPhoneNum() const { return phoneNum; }

  // Setters
  void setMemberID(string newMemID) { memberID = newMemID; }
  void setFirstName(string newFName) { fName = newFName; }
  void setLastName(string newLName) { lName = newLName; }
  void setEmail(string newEmail) { email = newEmail; }
  void setAddress(string newAddress) { address = newAddress; }
  void setPhoneNum(string newPhoneNum) { phoneNum = newPhoneNum; }

  // Display functions
  void displayAccount() const {
    cout << "First Name: " << fName << endl;
    cout << "Last Name: " << lName << endl;
    cout << "Membership ID: " << memberID << endl;
    cout << endl;
  }

  void displayAccountExtended() const {
    cout << "First Name: " << fName << endl;
    cout << "Last Name: " << lName << endl;
    cout << "Membership ID: " << memberID << endl;
    cout << "Email: " << email << endl;
    cout << "Address: " << address << endl;
    cout << "Phone Number: " << phoneNum << endl;
  /*
    cout << "Books checked out: " << endl;

    if (userBooks.empty()) {
      cout << "No books checked out." << endl;
    } else {
      for (const auto &pair : userBooks) {
        cout << pair.second.getTitle() << endl;
      }
    }
  */
    cout << endl;
  }

  /*
      // Check-out, Place-hold, Return functions
      void checkOut(Book& book) {
          book.setStatus("checked out");
          userBooks.push_back(book);
      }

      void placeHold(Book& book) {
          book.setStatus("holding");
      }

      void returnBook(Book& book) {
          book.setStatus("available");
          for (auto it = userBooks.begin(); it != userBooks.end(); ++it) {
              if (it->getTitle() == book.getTitle()) {
                  userBooks.erase(it);
                  break;
              }
          }
      }
  */
  bool isEmailUnique(const string &email, map<string, User> patrons);
};
#endif // USERCLASS_H
