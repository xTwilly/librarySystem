#ifndef LIBRARYSYSTEMCLASS_H
#define LIBRARYSYSTEMCLASS_H
#include "BookClass.h"
#include "Common.h"
#include "UserClass.h"

class LibrarySystem {
private:
  // All books in the library, searchable by ISBN
  map<string, Book> bookCollection;
  // All patrons of the library, searchable by MemberID
  map<string, User> patrons;

  // Functions
  void populateBookCollection();
  void populatePatronListFromFile();

public:
  // Constructors
  LibrarySystem();
  ~LibrarySystem() {}

  // Print
  void PrintAllBooks();
  void PrintAllUsers();

  // Accessors
  map<string, Book> getBookCollection();
  map<string, User> getPatronList();

  // Mutators
  void AddBookToList(Book newBook);
  void RemoveBookFromList(string ISBN);
  void RemoveBookFromList(Book oldBook);

  void addUser(User newUser);
  // Fixed Removed User Function errors and fixed the duplicate definition
  void removeUser(const User &oldUser);
  void removeUser(string memberID);

  void checkOutBook(string ISBN, User &user);
  void returnBook(string ISBN, User &user);
  void placeHoldBook(string ISBN, User &user);
  void removeHoldBook(string ISBN, User &user);

  // Andrew
  void addUserCSV(const User &newUser);
  void deleteUserCSV(const string &memberId);
};

LibrarySystem::LibrarySystem() {
  populateBookCollection();
  populatePatronListFromFile();
}

void LibrarySystem::populateBookCollection() {
  // Correct error handing, instead of exiting the program it will throw an
  // exception
  ifstream bookList("books.csv");
  if (!bookList.is_open()) {
    throw runtime_error("Could not open file.");
  }
  string line;
  string data;
  Book book;
  while (getline(bookList, line)) {
    istringstream lineParser(line);
    getline(lineParser, data, ','); // ISBN
    book.setISBN13(data);
    getline(lineParser, data, ','); // Authors  //Check Case: Multiple Authors?
    book.setAuthors(data);
    getline(lineParser, data, ','); // Year
    book.setYear(data);
    getline(lineParser, data, ','); // Title
    book.setTitle(data);
    getline(lineParser, data); // Rating
    book.setAverageRating(data);
    book.setStatus("Available");
    // Finished line
    bookCollection[book.getISBN13()] = book;
  }
  bookList.close();
}

void LibrarySystem::populatePatronListFromFile() {
  ifstream patronList;
  patronList.open("users.csv");
  if (!patronList.is_open()) {
    cout << "Could not open file." << endl;
    exit(1);
  }

  string fName, lName, email, address, phoneNum;
  string line;
  int memberID = 0; // Initialize memberID outside the loop

  while (getline(patronList, line)) {
    istringstream lineParser(line);
    getline(lineParser, fName, ',');
    getline(lineParser, lName, ',');
    getline(lineParser, email, ',');
    getline(lineParser, address, ',');
    getline(lineParser, phoneNum);

    // Increment memberID before assigning it to the user
    memberID++;

    // Create a new user and add it to the patrons map
    patrons[to_string(memberID)] =
        User(to_string(memberID), fName, lName, email, address, phoneNum);
  }
  patronList.close();
}

void LibrarySystem::PrintAllBooks() {
  // Iterate over book map
  for (auto iterator = bookCollection.begin(); iterator != bookCollection.end();
       ++iterator) {
    iterator->second.displayDetails();
  }
}

void LibrarySystem::PrintAllUsers() {
  // Iterate over User Map
  //  Fixed error too many arguments, removed iteraotor->second since its not
  //  required
  for (auto iterator = patrons.begin(); iterator != patrons.end(); iterator++) {
    iterator->second.displayAccountExtended();
  }
}

map<string, Book> LibrarySystem::getBookCollection() { return bookCollection; }

map<string, User> LibrarySystem::getPatronList() { return patrons; }

void LibrarySystem::AddBookToList(Book newBook) {
  // TODO: Check for existing book
  bookCollection[newBook.getISBN13()] = newBook;
}

void LibrarySystem::RemoveBookFromList(Book oldBook) {
  bookCollection.erase(oldBook.getISBN13());
}

void LibrarySystem::RemoveBookFromList(string ISBN) {
  bookCollection.erase(ISBN);
}

void LibrarySystem::addUser(User newUser) {
  patrons[newUser.getMemberID()] = newUser;
}

void LibrarySystem::removeUser(const User &oldUser) {
  patrons.erase(oldUser.getMemberID());
}

void LibrarySystem::removeUser(string memberID) { patrons.erase(memberID); }

void LibrarySystem::checkOutBook(string ISBN, User &user) {
  if (bookCollection.find(ISBN) != bookCollection.end()) {
    if (bookCollection[ISBN].getStatus().find("Available") != string::npos) {
      placeHoldBook(ISBN, user);
    }

    if (bookCollection[ISBN].getStatus().find("On Hold:") != string::npos) {
      if (bookCollection[ISBN].getStatus().find(user.getMemberID()) !=
          string::npos) {
        bookCollection[ISBN].setStatus("Checked Out:" + user.getMemberID());
        user.userBooks[ISBN] = bookCollection[ISBN];
        cout << bookCollection[ISBN].getTitle()
             << " checked out for user: " << user.getName() << endl;
      } else {
        cout << user.getName() << " has not placed a hold on this book."
             << endl;
      }
    } else {
      cout << "This book is not available." << endl;
    }
  } else {
    cout << "Book not found." << endl;
  }
}

void LibrarySystem::returnBook(string ISBN, User &user) {
  if (bookCollection.find(ISBN) != bookCollection.end()) {
    if (bookCollection[ISBN].getStatus().find("Checked Out:") != string::npos) {
      if (bookCollection[ISBN].getStatus().find(user.getMemberID()) !=
          string::npos) {
        bookCollection[ISBN].setStatus("Available");
        user.userBooks.erase(ISBN);
        cout << bookCollection[ISBN].getTitle() << " has been returned."
             << endl;
      } else {
        cout << user.getName() << " has not checked out this book." << endl;
      }
    } else {
      cout << "This book is not checked out." << endl;
    }
  } else {
    cout << "Book not found." << endl;
  }
}

void LibrarySystem::placeHoldBook(string ISBN, User &user) {
  if (bookCollection.find(ISBN) != bookCollection.end()) {
    if (bookCollection[ISBN].getStatus() == "Available") {
      bookCollection[ISBN].setStatus("On Hold:" + user.getMemberID());
      cout << bookCollection[ISBN].getTitle()
           << " on hold for user: " << user.getName() << endl;
    } else {
      cout << "This book is not available." << endl;
    }
  } else {
    cout << "Book not found." << endl;
  }
}

void LibrarySystem::removeHoldBook(string ISBN, User &user) {
  if (bookCollection.find(ISBN) != bookCollection.end()) {
    if (bookCollection[ISBN].getStatus().find("On Hold:") != string::npos) {
      if (bookCollection[ISBN].getStatus().find(user.getMemberID()) !=
          string::npos) {
        bookCollection[ISBN].setStatus("Available");
        cout << bookCollection[ISBN].getTitle() << " is now available." << endl;
      } else {
        cout << user.getName() << " has not placed a hold on this book."
             << endl;
      }
    } else {
      cout << "This book is not on hold." << endl;
    }
  } else {
    cout << "Book not found." << endl;
  }
}
void LibrarySystem::addUserCSV(const User &newUser) {
  ofstream file("users.csv", ios::app);
  if (!file.is_open()) {
    throw runtime_error("Could not open file.");
  }
  file << newUser.getFirstName() << "," << newUser.getLastName() << ","
       << newUser.getEmail() << "," << newUser.getAddress() << ","
       << newUser.getPhoneNum() << endl;

  file.close();
}

void LibrarySystem::deleteUserCSV(const string &memberId) {
  ifstream inputFile("users.csv");
  ofstream outputFile("temp.csv");

  if (!inputFile.is_open()) {
    cout << "Error opening input file." << endl;
    return;
  }
  if(!outputFile.is_open()){
    cout << "Error opening output file." << endl;
    return;
  }
  
  string line;

  // Read each line from the input file
  while (getline(inputFile, line)) {
      // Split the line into fields using a delimiter (comma)
      istringstream lineStream(line);
      vector<string> fields;
      string field;

      while (getline(lineStream, field, ',')) {
          fields.push_back(field);
      }

      // Check if the email field matches the memberId
      if (!fields.empty() && fields.size() >= 3 && fields[2] == memberId) {
          continue;  // Skip the line
      }

      // Write the line to the output file
      outputFile << line << endl;
  }

  inputFile.close();
  outputFile.close();

  if (remove("users.csv") != 0) {
      cerr << "Error removing original file." << endl;
      return;
  }

  if (rename("temp.csv", "users.csv") != 0) {
      cerr << "Error renaming temporary file." << endl;
  }
}
/*
bool User::isEmailUnique(const string& email, map<string, User> patronsList){
 //f
  return true;
}


bool User::isEmailUnique(const string& email, map<string, User> patronList){
  for (const auto &patron: patronList){
    if(patron.second.getEmail() == email){
      return false;
    }
    return true;
  }
  */

#endif // LIBRARYSYSTEMCLASS_H
