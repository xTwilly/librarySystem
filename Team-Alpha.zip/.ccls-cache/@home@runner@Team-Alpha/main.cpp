// Margarita Guzman, Chance Benna, Quinn Nagel
// Team Alpha project Library System

#include "Common.h"
#include "LibrarySystemClass.cpp"

void clearConsole() {cout << "\x1B[2J\x1B[H";}

int main() {
    // Switch Case Choice Value 1-8
    int choice;
    // Deeper Layer of UI Engagement 1-2 for both
    int bookChoice;
    int accountChoice;
    //User class specific variables
    User nullUser;
    string userBook;
    string memID;
    int userChoice;

    // Loop For Main UI
    while (true) {
        clearConsole();
        cout << "Welcome to the Library System!" << endl;
        cout << "------------------------------" << endl;
        cout << "Please select an option (1-8): " << endl;
        cout << "1. Return a Book" << endl;           // user
        cout << "2. Check out a Book" << endl;        // user
        cout << "3. Place a Book on Hold" << endl;    // user
        cout << "4. Display Book Details" << endl;    // book
        cout << "5. Add / Remove a Book" << endl;     // library systems + book?
        cout << "6. Display Account Details" << endl; // user
        cout << "7. Add / Remove an Account" << endl; // library systems
        cout << "8. Exit Program" << endl;
        choice = getInt(1, 8, "Select an option: ");

        // Main UI Switch Case
        switch (choice) {
            case 1: {
                clearConsole();
                cout << "Please enter the title of the book you would like to return: " << endl;
                cin >> userBook;
                //nullUser.returnBook(userBook);
                cout << "Returned a Book" << endl;
                break;
            }

            case 2: {
                clearConsole();
                cout << "Please enter the title of the book you would like to check out: " << endl;
                cin >> userBook;
                //nullUser.checkOut(userBook);
                cout << "Checked out a Book" << endl;
                break;
            }

            case 3: {
                clearConsole();
                cout << "Please enter the title of the book you would like to place on hold: " << endl;
                cin >> userBook;
                //nullUser.placeHold(userBook);
                cout << "Placed a Book on Hold" << endl;
                break;
            }

            case 4: {
                clearConsole();
                cout << "Displayed Book Details" << endl;
                break;
            }

            case 5: {
                clearConsole();
                cout << "Adding or Removing Books" << endl;
                cout << "------------------------" << endl;
                cout << "Please select an option (1 or 2): " << endl;
                cout << "1: Add a Book" << endl;
                cout << "2: Remove a Book" << endl;
                bookChoice = getInt(1, 2, "Select an option: ");

                switch (bookChoice) {
                    case 1: {
                        cout << "Added a Book" << endl;
                        break;
                    }

                    case 2: {
                        cout << "Removed a Book" << endl;
                        break;
                    }

                    default: {
                        cout << "Error!" << endl;
                        break;
                    }
                }
                break;
            }

            case 6: {
                clearConsole();
                cout << "Please enter the membership ID of said account: " << endl;
                cin >> memID;
                cout << "Would you like the extended or basic account details? (1-2)" << endl;
                cin >> userChoice;
                if (userChoice == 1 ){
                    //if(nullUser.membershipID == memID){
                    //displayAccount(nullUser);
                    //}
                }
                else if(userChoice == 2){
                    //if(nullUser.membershipID == memID){
                    //displayAccountExtended(nullUser);
                    //}
                }
                else{
                    cout << "Invalid Choice" << endl;
                    break;
                }

                cout << "Displayed Account Details" << endl;
                break;
            }

            case 7: {
                clearConsole();
                cout << "Added / Removed an Account" << endl;
                cin >> accountChoice;
                if (accountChoice == 1) {
                    cout << "Added an Account" << endl;
                } else if (accountChoice == 2) {
                    cout << "Removed an Account" << endl;
                } else {
                    cout << "Invalid Choice" << endl;
                }
                break;
            }

            case 8: {
                clearConsole();
                cout << "Exiting Program" << endl;
                exit(0);
            }

            default: {
                clearConsole();
                cout << "Invalid choice. Please try again." << endl;
                break;
            }
        }

        string tempString;
        cout << "Input anything to continue: ";
        cin >> tempString;
        cin.ignore();
    }

    return 0;
}