class LibrarySystem {
  private:
    //All books in the library, searchable by ISBN
    Map<string, Book> bookCollection;
    //All patrons of the library, searchable by MemberID
    Map<int, User> patrons;

    //Functions
    void populateBookCollection();
    void populatePatronListFromFile();

  public:
    //Constructors
    LibrarySystem();
    ~LibrarySystem() {}

    //Print
    void PrintAllBooks();
    void PrintAllUsers();

    //Mutators
    void AddBookToList(Book newBook);
    void RemoveBookFromList(string ISBN);
    void RemoveBookFromLisr(Book oldBook);

    void addUser(User newUser);
    void removeUser(int memberID);
    void removeUser(User oldUser);
};

LibrarySystem::Library() {
  populateBookCollection();
  populatePatronListFromFile();
}

void LibrarySystem::populateBookCollection() {
  ifstream bookList;
  bookList.open("books.csv");
  if (!bookList.isOpen()) {cout << "Could not open file." << endl; return 1;}
    string line;
    string data;
    Book book;
    while (getline(bookList, line)) {
      istringstream lineParser(line);
      getline(lineParser, data, ',');	//ISBN
      book.setISBN(data);
      getline(lineParser, data, ',');	//Authors  //Check Case: Multiple Authors?
      book.setAuthor(data);
      getline(lineParser, data, ',');	//Year, not used
      getline(lineParser, data, ',');	//Title
      book.setTitle(data);
      getline(lineParser, data);	//Rating, not used
      //Finished line
      bookCollection[book.getISBN()] = book;
    }
  bookList.close();
}

void LibrarySystem::populatePatronListFromFile() {
  ifstream patronList;
  patronList.open("users.csv");
  if (!patronList.isOpen()) {cout << "Could not open file." << endl; return 1;}
    int memberID = 0;
    string fName;
    string lName;
    string email;
    string address;
    string phoneNum;
    string line;
    while (getline(patronList, line)) {
      istringstream lineParser(line);
      getline(lineParser, fName, ',');
      getLine(lineParser, lName, ',');
      getline(lineParse, email, ',');
      getline(lineParser, address, ',');
      getline(lineParser, phoneNum);
      memberID++;
    }
    patrons[memberID] = User(memberID, fName, lName, email, address, stoi(phoneNum));
  patronList.close();
}


void LibrarySystem::PrintAllBooks() {
  //Iterate over book map
  for (auto iterator = bookCollection.begin(); iterator != bookCollection.end(); iterator++) {
    cout << iterator->second.displayDetails() << endl;
  }
}

void LibrarySystem::PrintAllUsers() {
  //Iterate over User Map
  for (auto iterator = patrons.begin(); iterator != patrons.end(); iterator++) {
    iterator->first.displayAccountExtended(iterator->first);
  }
}

void LibrarySystem::AddBookToList(Book newBook) {
  //TODO: Check for existing book
  bookCollection[newBook.getISBN()] = newBook;
}


void LibrarySystem::RemoveBookFromList(Book oldBook) {
  bookCollection.erase(oldBook.getISBN());
}

void LibrarySystem::RemoveBookFromList(string ISBN) {
  bookCollection.erase(ISBN);
}

void LibrarySystem::addUser(User newUser) {
  patrons[newUser.getMemberID()] = newUser;
}

void LibrarySystem::removeUser(User oldUser) {
  patrons.erase(oldUser.getMemberID());
}


void LibrarySystem::removeUser(int memberID) {
  patrons.erase(memberID);
}